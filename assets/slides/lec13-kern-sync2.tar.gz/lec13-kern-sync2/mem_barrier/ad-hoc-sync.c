#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
#include <sched.h>
#include <pthread.h>

#define NUM_THREAD 2
#define ____cacheline_aligned  __attribute__ ( (aligned (128)))

volatile int __dummy0, count, dummy1 ____cacheline_aligned;

/* compiler barrier */
static inline void smp_cmb(void)
{
	__asm__ __volatile__("":::"memory");
}

/* read memory barrier */
static inline void smp_rmb(void)
{
	__asm__ __volatile__("lfence":::"memory");
}

/* write memory barrier */
static inline void smp_wmb(void)
{
	__asm__ __volatile__("sfence":::"memory");
}

/* pin this thread to a particular cpu */
static int pin_to_cpu(int c)
{
        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(c, &cpuset);
        return sched_setaffinity(0, sizeof(cpuset), &cpuset);
}

static void *thread_main(void *arg)
{
	int cpu_id = (unsigned long)arg;
	int i;

	/* pin this thread to cpu_id */
	pin_to_cpu(cpu_id);

	/* start! */
	printf("[%s:%d] ## Start cpu_id %d with count %d\n",
	       __func__, __LINE__, cpu_id, count);
	for (i = 0; i < 100;) {
		if ((count % NUM_THREAD) == cpu_id) {
			count++;
			i++;
		}
	}

	printf("[%s:%d] ## End cpu_id %d with count %d\n",
	       __func__, __LINE__, cpu_id, count);
	return NULL;
}

int main(int argc, char *argv[])
{
	pthread_t cpu_id[NUM_THREAD];
	unsigned long i;
	int rc;

	/* create and start two ping-pong threads */
	printf("[%s:%d] ** Creating two threads\n", __func__, __LINE__);
	for (i = 0; i < NUM_THREAD; ++i) {
		pthread_create(cpu_id+i, NULL, thread_main, (void *)i);
	}

	/* wait until all threads terminate */
	printf("[%s:%d] ** Waiting termination of two threads\n", __func__, __LINE__);
	for (i = 0; i < NUM_THREAD; ++i) {
		pthread_join(cpu_id[i], NULL);
	}
	printf("[%s:%d] ** Existing\n", __func__, __LINE__);
	return 0;
}
