#!/bin/bash
QEMU_BIN=qemu-system-x86_64
NCPU=2
MEMSIZE=2G

#KNL_SRC=~/linux-6.1.74	# TODO: Change with your kernel base location
KNL_SRC=~/linux-6.7.1	# TODO: Change with your kernel base location
BZIMAGE=${KNL_SRC}/arch/x86/boot/bzImage
CMDLINE="nokaslr console=ttyS0 root=/dev/sda3"

sudo ${QEMU_BIN} \
    -s \
    -nographic \
    -enable-kvm \
    -smp ${NCPU} -m ${MEMSIZE} \
    -nic user,host=10.0.2.10,hostfwd=tcp:127.0.0.1:2222-:22 \
    -net nic,model=e1000 \
    -drive file=alpine.qcow2,format=qcow2 \
    -kernel ${BZIMAGE} \
    -append "${CMDLINE}"

