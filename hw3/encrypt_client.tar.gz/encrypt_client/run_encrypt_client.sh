./encrypt_client -s "hello" -k 1
